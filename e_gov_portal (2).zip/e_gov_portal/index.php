<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rural E-Governance Portal - Digital Services for Rural Citizens</title>
    <meta name="description" content="Access government services online - Apply for certificates, track applications, and access welfare schemes from your home.">
    <meta name="keywords" content="e-governance, rural, government services, certificates, online applications, digital india">
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <i class="fas fa-building"></i>
                <span class="brand-text">Rural E-Governance Portal</span>
            </div>
            <div class="nav-menu" id="navMenu">
                <button class="nav-item active" data-page="dashboard">
                    <i class="fas fa-home"></i>
                    <span class="nav-text">Dashboard</span>
                </button>
                <button class="nav-item" data-page="services">
                    <i class="fas fa-file-alt"></i>
                    <span class="nav-text">Services</span>
                </button>
                <button class="nav-item" data-page="applications">
                    <i class="fas fa-search"></i>
                    <span class="nav-text">My Applications</span>
                </button>
                <button class="nav-item" data-page="schemes">
                    <i class="fas fa-gift"></i>
                    <span class="nav-text">Schemes</span>
                </button>
                <button class="nav-item" data-page="grievance">
                    <i class="fas fa-comment-dots"></i>
                    <span class="nav-text">Grievance</span>
                </button>
            </div>
            
            <div class="nav-actions">
                <button class="lang-toggle" id="langToggle">
                    <i class="fas fa-language"></i>
                    <span>हिंदी</span>
                </button>
                <button class="login-btn" id="loginBtn" onclick="window.location.href='login.html'">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Log In</span>
                    </button>
                    </div>
                <button class="profile-btn">
                    <i class="fas fa-user"></i>
                </button>
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </nav>
    <!-- Main Content -->
    <main class="main-content">
        <!-- Dashboard Page -->
        <div class="page active" id="dashboard">
            <!-- Hero Section -->
            <section class="hero">
                <div class="hero-content">
                    <h1 class="hero-title">Welcome to Digital Government Services</h1>
                    <p class="hero-subtitle">Access government services from the comfort of your home</p>
                    <div class="hero-actions">
                        <button class="btn btn-primary" data-action="new-application">
                            <i class="fas fa-file-plus"></i>
                            New Application
                        </button>
                        <button class="btn btn-secondary" data-action="track-application">
                            <i class="fas fa-search"></i>
                            Track Application
                        </button>
                    </div>
                </div>
            </section>

            <!-- Quick Services -->
            <section class="quick-services">
                <h2 class="section-title">Quick Services</h2>
                <div class="services-grid">
                    <div class="service-card">
                        <div class="service-icon blue">
                            <i class="fas fa-download"></i>
                        </div>
                        <h3>Download Forms</h3>
                        <p>Download application forms</p>
                        <i class="fas fa-chevron-right"></i>
                    </div>
                    <div class="service-card">
                        <div class="service-icon green">
                            <i class="fas fa-upload"></i>
                        </div>
                        <h3>Upload Documents</h3>
                        <p>Upload required documents</p>
                        <i class="fas fa-chevron-right"></i>
                    </div>
                    <div class="service-card">
                        <div class="service-icon purple">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h3>Track Application</h3>
                        <p>Check your application status</p>
                        <i class="fas fa-chevron-right"></i>
                    </div>
                    <div class="service-card">
                        <div class="service-icon red">
                            <i class="fas fa-comment-dots"></i>
                        </div>
                        <h3>Grievance</h3>
                        <p>File a complaint or grievance</p>
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </section>

            <!-- Popular Services -->
            <section class="popular-services">
                <div class="section-header">
                    <h2 class="section-title">Popular Services</h2>
                    <button class="view-all-btn" data-action="view-services">
                        View All <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                <div class="popular-grid" id="popularServices">
                    <!-- Services will be populated by JavaScript -->
                </div>
            </section>

            <!-- Recent Applications -->
            <section class="recent-applications">
                <h2 class="section-title">Recent Applications</h2>
                <div class="applications-list" id="recentApplications">
                    <!-- Applications will be populated by JavaScript -->
                </div>
            </section>

            <!-- Contact Information -->
            <section class="contact-info">
                <div class="contact-grid">
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h3>Emergency Helpline</h3>
                            <p>1800-123-4567</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h3>Email Support</h3>
                            <p>support@egovportal.gov.in</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h3>Visit Office</h3>
                            <p>Block Development Office</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- Services Page -->
        <div class="page" id="services">
            <div class="page-header">
                <h1>Government Services</h1>
                <p>Browse all available government services and submit applications online</p>
            </div>
            
            <div class="services-categories">
                <div class="category-section">
                    <div class="category-header">
                        <div class="category-icon blue">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h2>Certificates</h2>
                    </div>
                    <div class="category-services" id="certificateServices">
                        <!-- Certificate services will be populated by JavaScript -->
                    </div>
                </div>

                <div class="category-section">
                    <div class="category-header">
                        <div class="category-icon green">
                            <i class="fas fa-building"></i>
                        </div>
                        <h2>Welfare Schemes</h2>
                    </div>
                    <div class="category-services" id="welfareServices">
                        <!-- Welfare services will be populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Applications Page -->
        <div class="page" id="applications">
            <div class="page-header">
                <h1>My Applications</h1>
                <p>Track the status of your submitted applications</p>
            </div>

            <!-- Application Tracking -->
            <section class="track-section">
                <h2>Track Application</h2>
                <div class="track-form">
                    <input type="text" id="trackingId" placeholder="Enter Application ID" class="track-input">
                    <button class="btn btn-primary" id="trackBtn">
                        <i class="fas fa-search"></i>
                        Track Now
                    </button>
                </div>
            </section>

            <!-- Applications List -->
            <section class="applications-section">
                <h2>Your Applications</h2>
                <div class="applications-detailed" id="applicationsDetailed">
                    <!-- Detailed applications will be populated by JavaScript -->
                </div>
            </section>
        </div>

        <!-- Schemes Page -->
        <div class="page" id="schemes">
            <div class="page-header">
                <h1>Government Schemes</h1>
                <p>Explore various government welfare schemes and benefits</p>
            </div>
            
            <div class="schemes-grid" id="schemesGrid">
                <!-- Schemes will be populated by JavaScript -->
            </div>
        </div>

        <!-- Grievance Page -->
        <div class="page" id="grievance">
            <div class="page-header">
                <h1>Grievance Portal</h1>
                <p>File complaints and track their resolution status</p>
            </div>
            
            <div class="grievance-content">
                <div class="grievance-form-section">
                    <h2>File New Grievance</h2>
                    <form class="grievance-form" id="grievanceForm">
                        <div class="form-group">
                            <label for="grievanceType">Grievance Type</label>
                            <select id="grievanceType" required>
                                <option value="">Select Type</option>
                                <option value="service-delay">Service Delay</option>
                                <option value="corruption">Corruption</option>
                                <option value="poor-service">Poor Service Quality</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="grievanceSubject">Subject</label>
                            <input type="text" id="grievanceSubject" required>
                        </div>
                        <div class="form-group">
                            <label for="grievanceDescription">Description</label>
                            <textarea id="grievanceDescription" rows="5" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="grievanceFile">Attach Document (Optional)</label>
                            <input type="file" id="grievanceFile" accept=".pdf,.jpg,.png,.doc,.docx">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i>
                            Submit Grievance
                        </button>
                    </form>
                </div>
                
                <div class="grievance-status-section">
                    <h2>Track Grievance Status</h2>
                    <div class="track-form">
                        <input type="text" id="grievanceTrackingId" placeholder="Enter Grievance ID">
                        <button class="btn btn-secondary" id="trackGrievanceBtn">
                            <i class="fas fa-search"></i>
                            Track
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <div class="footer-brand">
                    <i class="fas fa-building"></i>
                    <span>Rural E-Governance Portal</span>
                </div>
                <p>Digital Services for Rural Citizens</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#dashboard">Dashboard</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#applications">Applications</a></li>
                    <li><a href="#schemes">Schemes</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Support</h3>
                <ul>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">User Guide</a></li>
                    <li><a href="#">FAQs</a></li>
                    <li><a href="#grievance">Grievance</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <div class="contact-details">
                    <p><i class="fas fa-phone"></i> 1800-123-4567</p>
                    <p><i class="fas fa-envelope"></i> support@egovportal.gov.in</p>
                    <p><i class="fas fa-globe"></i> www.egovportal.gov.in</p>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Rural E-Governance Portal. All rights reserved. | Government of India</p>
        </div>
    </footer>

    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading...</p>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal" id="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Modal Title</h3>
                <button class="modal-close" id="modalClose">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Modal content will be populated by JavaScript -->
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>